﻿namespace DataCaptureService
{
    public enum CaptureState
    {
        ProcessingFiles,
        WaitingForFiles
    }
}
