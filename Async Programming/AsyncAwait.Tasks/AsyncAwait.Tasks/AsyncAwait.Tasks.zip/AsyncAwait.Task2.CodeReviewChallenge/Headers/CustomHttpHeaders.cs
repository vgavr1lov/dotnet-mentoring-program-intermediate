﻿namespace AsyncAwait.Task2.CodeReviewChallenge.Headers;

public class CustomHttpHeaders
{
    public const string TotalPageVisits = "TotalPageVisits";
}
